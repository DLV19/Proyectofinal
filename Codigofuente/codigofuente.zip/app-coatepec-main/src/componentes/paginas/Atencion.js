import React from 'react'

const Atencion = () => {
  return (
    <div>
      <h1>Página de Atencion</h1>
    </div>
  )
}

export default Atencion
