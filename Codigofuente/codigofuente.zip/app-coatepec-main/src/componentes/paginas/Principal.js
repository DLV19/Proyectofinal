import React from 'react';
import Carrusel from '../navegacion/Carrusel';
import '../hojasEstilos/general.css';

const Principal = () => {
  return (
    <div id="centroCarrucel">
      <Carrusel />
    </div>
  )
}

export default Principal
