import React from 'react';
import '../hojasEstilos/general.css';
import Barra from '../navegacion/Barra';

const Accesibilidad = () => {
  return (
    <div>
      <h1>Página de Accesibilidad</h1>
    </div>
  )
}

export default Accesibilidad
