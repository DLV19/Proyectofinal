import React from 'react'
import '../hojasEstilos/general.css';

const Ayuda = () => {
  return (
    <div>
      <h1>Página de Ayuda</h1>
    </div>
  )
}

export default Ayuda
